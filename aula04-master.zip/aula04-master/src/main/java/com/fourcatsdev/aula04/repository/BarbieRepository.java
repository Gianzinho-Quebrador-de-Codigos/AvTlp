package com.fourcatsdev.aula04.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fourcatsdev.aula04.modelo.Barbie;

public interface BarbieRepository extends JpaRepository<Barbie, Long> {

}
