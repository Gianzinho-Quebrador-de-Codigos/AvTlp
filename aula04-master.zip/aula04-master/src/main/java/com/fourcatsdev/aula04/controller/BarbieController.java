package com.fourcatsdev.aula04.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fourcatsdev.aula04.modelo.Barbie;
import com.fourcatsdev.aula04.repository.BarbieRepository;

@Controller
@RequestMapping("/barbie")
public class BarbieController {
	
	@Autowired
	private BarbieRepository barbieRepository;
	
	@GetMapping("/novo")
	public String adicionarBarbie(Model model) {
		model.addAttribute("barbie", new Barbie());
		return "/publica-criar-barbie";
	}
	
	@PostMapping("/salvar")
	public String salvarBarbie(@Valid Barbie barbie, BindingResult result, 
				RedirectAttributes attributes) {
		if (result.hasErrors()) {
			return "/publica-criar-barbie";
		}	
		barbieRepository.save(barbie);
		attributes.addFlashAttribute("mensagem", "Barbie salva com sucesso!");
		return "redirect:/barbie/novo";
	}
	
	@RequestMapping("/admin/listar")
	public String listarBarbie(Model model) {
		model.addAttribute("barbies", barbieRepository.findAll());		
		return "/auth/admin/admin-listar-barbie";		
	}
	
	@GetMapping("/admin/apagar/{id}")
	public String deleteBarbie(@PathVariable("id") long id, Model model) {
		Barbie barbie = barbieRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Id inválido:" + id));
		barbieRepository.delete(barbie);
	    return "redirect:/barbie/admin/listar";
	}
	
	@GetMapping("/editar/{id}")
	public String editarBarbie(@PathVariable("id")long id, Model model) {
		Optional<Barbie> barbieVelho = barbieRepository.findById(id);
		if (!barbieVelho.isPresent()) {
			throw new IllegalArgumentException("Barbie inválida:" +id);	
		}
		Barbie barbie = barbieVelho.get();
		model.addAttribute("barbie", barbie);
		return "/auth/user/user-alterar-barbie";
	}
	
	@PostMapping("/editar/{id}")
	public String editarBarbie(@PathVariable("id") long id, @Valid Barbie berbie, 
	  BindingResult result, RedirectAttributes attributes) {
	    if (result.hasErrors()) {
	    	berbie.setId(id);
	        return "/auth/user/user-alterar-barbie";
	    }
	    barbieRepository.save(berbie);
	    attributes.addFlashAttribute("mensagem", "Barbie alterada com sucesso!");
		return "redirect:/berbie/novo";
	}
}
	
	
